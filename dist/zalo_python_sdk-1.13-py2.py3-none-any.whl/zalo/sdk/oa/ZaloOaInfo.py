class ZaloOaInfo:
    def __init__(self, oa_id, secret_key):
        self.oa_id = oa_id
        self.secret_key = secret_key
        self.name = None
        self.avatar = None
        self.cover = None
        self.description = None